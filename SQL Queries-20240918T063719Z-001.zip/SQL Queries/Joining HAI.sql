DROP TABLE [Hourly Activity Info];

-- Writing a Query to Create a New Table
CREATE TABLE [Hourly Activity Info] (
    [HourlyID] INT IDENTITY(1,1) PRIMARY KEY,
    [Id] BIGINT,
    [ActivityHour] DATETIME,
    [AverageIntensity] INT,
    [TotalIntensity] INT,
    [StepTotal] INT,
    [Calories] INT
	);

-- Making a Query to Insert the Data into the New Table
INSERT INTO [Hourly Activity Info] (
    [Id],
	[ActivityHour],
	[AverageIntensity],
	[TotalIntensity],
	[StepTotal],
	[Calories]
	)
SELECT 
    s.[Id],
    s.[ActivityHour],
	i.[AverageIntensity],
    i.[TotalIntensity],
	s.[StepTotal],
    c.[Calories]
FROM 
    [FitBit].[dbo].[HSteps_M] s
LEFT JOIN 
    [FitBit].[dbo].[HIntensities_M] i ON s.[Id] = i.[Id] AND s.[ActivityHour] = i.[ActivityHour]
LEFT JOIN 
    [FitBit].[dbo].[HCalories_M] c ON s.[Id] = c.[Id] AND s.[ActivityHour] = c.[ActivityHour];

--Taking a Look at our Newly Created Table
SELECT TOP (100) [HourlyID]
      ,[Id]
      ,[AverageIntensity]
      ,[TotalIntensity]
      ,[StepTotal]
      ,[Calories]
  FROM [FitBit].[dbo].[Hourly Activity Info];