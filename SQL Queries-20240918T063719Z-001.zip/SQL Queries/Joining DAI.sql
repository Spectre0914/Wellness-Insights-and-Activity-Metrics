DROP TABLE [Daily Activity Info];

-- Writing a Query to Create a New Table
CREATE TABLE [Daily Activity Info] (
    [DailyID] INT IDENTITY(1,1) PRIMARY KEY,
    [Id] BIGINT,
    [ActivityDay] DATE,
    [SedentaryMinutes] INT,
    [LightlyActiveMinutes] INT,
    [FairlyActiveMinutes] INT,
    [VeryActiveMinutes] INT,
    [SedentaryActiveDistance] FLOAT,
    [LightActiveDistance] FLOAT,
    [ModeratelyActiveDistance] FLOAT,
    [VeryActiveDistance] FLOAT,
    [TotalDistance] FLOAT,
    [TrackerDistance] FLOAT,
    [StepTotal] INT,
	[Calories] INT
	);

-- Making a Query to Insert the Data into the New Table
INSERT INTO [Daily Activity Info] (
    [Id],
    [ActivityDay],
    [SedentaryMinutes],
    [LightlyActiveMinutes],
    [FairlyActiveMinutes],
    [VeryActiveMinutes],
    [SedentaryActiveDistance],
    [LightActiveDistance],
    [ModeratelyActiveDistance],
    [VeryActiveDistance],
    [TotalDistance],
    [TrackerDistance],
    [StepTotal],
	[Calories]
	)
  SELECT
    DA.Id,
    DA.ActivityDay,
    DA.SedentaryMinutes,
    DA.LightlyActiveMinutes,
    DA.FairlyActiveMinutes,
    DA.VeryActiveMinutes,
    DA.SedentaryActiveDistance,
    DA.LightActiveDistance,
    DA.ModeratelyActiveDistance,
    DA.VeryActiveDistance,
    DD.TotalDistance,
    DD.TrackerDistance,
    DS.StepTotal,
	DC.Calories
FROM dbo.DAIntesities_M DA
INNER JOIN dbo.DACalories_M DC
    ON DA.Id = DC.Id
    AND DA.ActivityDay = DC.ActivityDay
INNER JOIN dbo.DADistance_M DD
    ON DA.Id = DD.Id
    AND DA.ActivityDay = DD.ActivityDate
INNER JOIN dbo.DASteps_M DS
    ON DA.Id = DS.Id
    AND DA.ActivityDay = DS.ActivityDay;

--Insert a new column in our Database
ALTER TABLE [Daily Activity Info]
ADD [Activity Score] VARCHAR(50);

--Query to assign Activity Scores to our Users
UPDATE [Daily Activity Info]
SET [Activity Score] = CASE
    WHEN StepTotal < 5000 THEN 'Low Activity'
    WHEN StepTotal BETWEEN 5000 AND 7498 THEN 'Moderate Activity'
    WHEN StepTotal BETWEEN 7499 AND 9998 THEN 'Significant Activity'
    ELSE 'High Activity'
END;

--Taking a Look at our Newly Created Table
SELECT TOP (100) [DailyID]
      ,[Id]
      ,[ActivityDay]
      ,[SedentaryMinutes]
      ,[LightlyActiveMinutes]
      ,[FairlyActiveMinutes]
      ,[VeryActiveMinutes]
      ,[SedentaryActiveDistance]
      ,[LightActiveDistance]
      ,[ModeratelyActiveDistance]
      ,[VeryActiveDistance]
      ,[TotalDistance]
      ,[StepTotal]
      ,[Calories]
      ,[Activity Score]
  FROM [FitBit].[dbo].[Daily Activity Info];

--To know our Server Name
SELECT @@SERVERNAME;